% Path preample for NQS:

NQS_root = '** your directory **/NQS-VMC/';

addpath(genpath('NQS_root'));